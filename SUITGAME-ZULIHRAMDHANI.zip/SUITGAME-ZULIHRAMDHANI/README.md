
# ===== GAME-SUIT-TERMINAL =====


Challenge untuk Class Gold Boothcamp Binar Academy
Kelas Android Engineering Wave 13.


By. Zul Ihram Dhani