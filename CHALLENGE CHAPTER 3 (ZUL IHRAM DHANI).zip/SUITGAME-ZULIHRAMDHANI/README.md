
# ===== GAME-SUIT-TERMINAL =====


Challenge untuk Class Gold Boothcamp Binar Academy
Kelas Android Engineering Wave 13.


Oleh : Zul Ihram Dhani

Semoga bisa sesuai kriteria untuk mengikuti next chapt Amiin :D